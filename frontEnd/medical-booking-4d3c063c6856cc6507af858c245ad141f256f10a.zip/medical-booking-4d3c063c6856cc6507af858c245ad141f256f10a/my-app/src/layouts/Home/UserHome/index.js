import DoctorList from '../../Doctors/doctorList'

function index() {
  return <DoctorList />
}

export default index
