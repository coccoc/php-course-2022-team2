import BookingSchedule from '../../DocterView/BookingSchedule'

function index() {
  return <BookingSchedule />
}

export default index
