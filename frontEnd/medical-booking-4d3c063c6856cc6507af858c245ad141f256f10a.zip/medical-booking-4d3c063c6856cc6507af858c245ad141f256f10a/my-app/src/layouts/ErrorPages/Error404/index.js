import { Box, Button } from '@mui/material'
import { Link, NavLink, useNavigate } from 'react-router-dom'

function index() {
  // const navigate = useNavigate()
  return (
    <Box className="errorPage" sx={{ height: `${window.innerHeight}px` }}>
      <Box className="errorPage-container">
        <Box className="errorPage-header">
          <span className="errorPage-header-errorType">404</span>
          <span className="errorPage-header-errorTitle">We're working on it</span>
        </Box>
        <Box className="errorPage-404 errorPage-bg"></Box>
        <Box className="errorPage-button">
          <NavLink className="errorPage-button-link" to="/">
            <Button variant="contained">Back to home</Button>
          </NavLink>
        </Box>
      </Box>
    </Box>
  )
}

export default index
