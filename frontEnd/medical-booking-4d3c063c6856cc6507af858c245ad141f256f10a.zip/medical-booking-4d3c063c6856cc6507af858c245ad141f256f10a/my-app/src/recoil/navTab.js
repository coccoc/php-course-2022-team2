import { atom } from 'recoil'

export const navTab = atom({
  key: 'navTab',
  default: 'Home',
})
