import { atom } from 'recoil'

export const profileTab = atom({
  key: 'profileTab',
  default: 'profile',
})
